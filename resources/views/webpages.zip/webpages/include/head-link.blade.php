<meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Book Factory</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Use Minified Plugins Version For Fast Page Load -->
    <link rel="stylesheet" type="text/css" media="screen" href="{{asset('public/webpages/assets/css/plugins.css')}}" />
    <link rel="stylesheet" type="text/css" media="screen" href="{{asset('public/webpages/assets/css/main.css')}}" />
    <link rel="shortcut icon" type="image/x-icon" href="{{asset('public/webpages/assets/image/favicon.png')}}">
    